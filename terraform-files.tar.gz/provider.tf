terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region     = "eu-west-3"
  access_key = "AKIAR22IPVNI5FWLXXXR"
  secret_key = "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"
}